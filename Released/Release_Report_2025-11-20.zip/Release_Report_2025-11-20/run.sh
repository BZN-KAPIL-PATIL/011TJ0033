#!/bin/bash
cd /home/bznpwrusr/Installation/GPX_AbbottConverter
java -jar GPX_AbbottConverter.jar




