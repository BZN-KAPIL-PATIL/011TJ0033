#!/bin/bash
cd /home/bznpwrusr/Desktop/Daily_Work/October/20_Oct/Release_Report_2025-10-20
java -jar GPX_AbbottConverter.jar




